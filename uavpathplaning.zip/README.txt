main.m is the entrance of the methods 
enemyGuass.m is risk module
drawBackground.m is drawing the results 

There are some calls for the source code. 
Here is a version for path planing based on geometric reinforcement learning, however I' am not sure with whether it is the final one or not, sicne the students who did the implementation are not doing research, But I think the version can be a good paltform for the interested researchers in this field. 
I feel sorry for the update for the further version.
Baochang zhang 